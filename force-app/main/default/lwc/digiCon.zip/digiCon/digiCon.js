import { LightningElement, track } from 'lwc';

export default class DigiCon extends LightningElement {
  @track isModalOpen = false;
  @track isAssetSelectorOpen = false; // State for asset selector modal
  @track documentLinks = [];
  @track assetRows = []; // State for dynamically added rows

  connectedCallback() {
    window.addEventListener('onAssetsSelectedEvent', this.onAssetsSelected.bind(this)); // Listen for asset selector events
  }

  openModal() {
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
  }

  openAssetSelector(event) {
    const rowId = event.target.dataset.id; // Track which row this belongs to
    this.isAssetSelectorOpen = true;
    this.selectedRowId = rowId; // Store row ID for later use
    this.loadAssetSelector(); // Load the asset selector
  }

  closeAssetSelector() {
    this.isAssetSelectorOpen = false;
  }

  handleAssetNameChange(event) {
    const rowId = parseInt(event.target.dataset.id, 10); // Row ID from data-id
    const newValue = event.target.value;
    this.assetRows = this.assetRows.map(row => row.id === rowId ? { ...row, name: newValue } : row);
  }

  onAssetsSelected(event) {
    const asset = event.detail[0];
    const renditionLinks = this.getAssetRenditionLinks(asset);
    const optimalRenditionLink = this.getOptimalRenditionLink(renditionLinks);
    this.assetRows = this.assetRows.map(row => row.id === this.selectedRowId ? { ...row, name: asset.name, url: optimalRenditionLink.href } : row);
    this.closeAssetSelector();
  }

  getAssetRenditionLinks(asset) {
    return asset?._links?.['http://ns.adobe.com/adobecloud/rel/rendition'];
  }

  getOptimalRenditionLink(renditions) {
    return renditions.reduce((optimal, current) => {
      const optimalResolution = optimal.width * optimal.height;
      const currentResolution = current.width * current.height;
      return currentResolution > optimalResolution ? current : optimal;
    });
  }

  addNewRow() {
    const newRow = {
      id: this.assetRows.length,
      name: '',
      url: ''
    };
    this.assetRows = [...this.assetRows, newRow];
  }

  addDocument() {
    this.documentLinks = [...this.documentLinks, ...this.assetRows.map(row => ({
      id: this.documentLinks.length + row.id, name: row.name, url: row.url
    }))];
    this.assetRows = []; // Clear rows
    this.closeModal();
  }

  removeDocument(event) {
    const id = parseInt(event.target.dataset.id, 10);
    this.documentLinks = this.documentLinks.filter(link => link.id != id);
  }

  removeRow(event) {
    const rowId = parseInt(event.target.dataset.id, 10);
    this.assetRows = this.assetRows.filter(row => row.id != rowId);
  }

  loadAssetSelector() {
    console.log("initializing Asset Selector");
// get the container element in which we want to render the AssetSelector component
const container = document.getElementById('asset-selector-container');
// imsOrg and imsToken are required for authentication in non-SUSI flow
const apiToken = "eyJhbGciOiJSUzI1NiIsIng1dSI6Imltc19uYTEta2V5LWF0LTEuY2VyIiwia2lkIjoiaW1zX25hMS1rZXktYXQtMSIsIml0dCI6ImF0In0.eyJpZCI6IjE3MTQxNTM1MzEyNzFfMmUyOWM5NDEtZmExYi00ZTRjLWE1ZmItNmU3MDZiOWY0OGFlX3VlMSIsIm9yZyI6IkRBNUI1QjNCNTJGNTNCMTYwQTQ5MEQ0NEBBZG9iZU9yZyIsInR5cGUiOiJhY2Nlc3NfdG9rZW4iLCJjbGllbnRfaWQiOiI0NjQ4ZmNlYWQ1MTY0OTZjOGMzYmNmODlkMTM5NzFmYyIsInVzZXJfaWQiOiI5MzRGMUQ4NDY2Mjg1Q0VFMEE0OTVFODRAdGVjaGFjY3QuYWRvYmUuY29tIiwiYXMiOiJpbXMtbmExIiwiYWFfaWQiOiI5MzRGMUQ4NDY2Mjg1Q0VFMEE0OTVFODRAdGVjaGFjY3QuYWRvYmUuY29tIiwiY3RwIjozLCJtb2kiOiJjMmUwYjgxNiIsImV4cGlyZXNfaW4iOiI4NjQwMDAwMCIsImNyZWF0ZWRfYXQiOiIxNzE0MTUzNTMxMjcxIiwic2NvcGUiOiJvcGVuaWQsQWRvYmVJRCxhZGRpdGlvbmFsX2luZm8ucHJvamVjdGVkUHJvZHVjdENvbnRleHQifQ.DYa9U6s8MzTS0wOfyKfxg-WgYYKVeJetVpI-eQTk-NR4FIH_7lGaX0rAXXRNFCRwQGNdR24wo2EvnnovYRV4hN47jFMDixn8zp3Ww_fLi9MCpHg9ZVnb71vYUd-KJljoX82HxjpDX-I8xrdpOs33x7bZYF8Yh9EwWH-7jGZHaEX3UyBDO3oP1ChMhQtjJQtI5Eycae69rN_7cWJI0s5MONLJzhlSmcrGzlzHgG9asNVtnhu04UZ7Uud04zB3NY3To1DMAl2zi3LTNJuoUFe7u_SRhZPWIMc48Y_ufFfDonvSoU3zX_cRjT8xpu0QCpCGAbm05IcAkZL5cc-JTrQQfA";
/**
 * Props for the asset selector UI.
 *
 * @typedef {Object} AssetSelectorProps
 * @property {string} discoveryURL - The URL for the AEM Discovery service.
 * @property {string} imsOrg - The IMS organization ID for the user.
 * @property {string} apiKey - The API key for the AEM Assets backend.
 * @property {Function} onClose - A callback function to be called when the asset selector dialog is closed.
 * @property {Function} handleSelection - A callback function to be called when an asset is selected.
 * @property {Function} handleNavigateToAsset - A callback function to be called when the user clicks on an asset to navigate to it.
 * @property {string} env - The environment where the asset selector is being used.
 * @property {string} selectionType - Specifies whether to allow single or multiple asset selection. Options single | multiple
 * @property {boolean} hideTreeNav - Specifies whether to show or hide assets tree navigation sidebar. It is used in modal view only and hence there is no effect of this property in rail view.
 */
const assetSelectorProps = {
    repositoryId : "delivery-p133222-e1298749.adobeaemcloud.com",
    imsOrg: 'DA5B5B3B52F53B160A490D44@AdobeOrg',
    imsToken: apiToken,
    apiKey: "aemcs-ulsolutions-assetselector",
    rootPath: "/content/dam/playground",
    selectionType: "single",
    hideTreeNav: true,
    onClose: handleClose,
    handleSelection,
};
// Call the `renderAssetSelector` available in PureJSSelectors globals to render AssetSelector
//PureJSSelectors.renderAssetSelector(container, assetSelectorProps);
/**
 * Renders the asset selector UI, and shows the dialog when it's ready.
 *
 * @function renderAssetSelector
 * @param {Element} container - The container element where the asset selector will be rendered.
 * @param {AssetSelectorProps} props - Props for the asset selector UI.
 * @param {Function} callback - A callback function to be called when the UI is ready to be displayed.
 */
 PureJSSelectors.renderAssetSelector(container, assetSelectorProps, () => {
    const assetSelectorDialog = document.getElementById('asset-selector-dialog');
    assetSelectorDialog.showModal();
});
    
    
  }
}
